package org.antlr.v4.runtime.misc;

public interface Predicate<T> {
	boolean test(T t);
}
